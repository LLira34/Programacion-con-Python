# practice2LFLG.py

def calculate(distance:float, time:float) -> str:
    speed = distance / time
    return str(speed)
