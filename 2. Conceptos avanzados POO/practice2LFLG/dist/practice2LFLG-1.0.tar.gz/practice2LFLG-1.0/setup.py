# setup.py

from setuptools import setup
setup(name = "practice2LFLG",
      version = "1.0",
      description = "The head first python search tools",
      author = "Luis Fernando Lira Garcia",
      author_email = "luislira1029@gmail.com",
      url = "headfirstlabs.com",
      py_modules = ["practice2LFLG"])
